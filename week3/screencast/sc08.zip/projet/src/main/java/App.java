public class App {
  public static void main(String argv[]) {
    System.out.println("Hello");
  }
}
